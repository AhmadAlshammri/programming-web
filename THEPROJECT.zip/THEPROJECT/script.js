function openfunction() {
    document.getElementById('menu').style.width = '250px';

}

function closefunction() {
    document.getElementById('menu').style.width = '0px';

}